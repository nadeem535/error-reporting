This project generate a report on Errors logged in daily CH Accumulator and Pre-adjudication processing.
